gigaverb~ version 1.0test3
reverb external for Max/MSP
written by Olaf Matthes <olaf.matthes@gmx.de>
GVerb implementation by Juhana Sadeharju <kouhia@nic.funet.fi>

This software is published under GPL terms, see file LICENSE.txt.

This is software with ABSOLUTELY NO WARRANTY.
Use it at your OWN RISK. It's possible to damage e.g. hardware or your 
hearing due to a bug or for other reasons. 

Recent changes:
- improvements in the reverb parameters, thus better sound
- improved check for NANs (significant CPU improvement on Windows)
- now inlinig crutial code on Mac
- added some presets to the help file

The latest version of gigaverb~ is available from:
http://www.akustische-kunst.org/maxmsp/